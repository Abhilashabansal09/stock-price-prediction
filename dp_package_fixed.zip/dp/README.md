
# Stock Price Prediction Project

This project focuses on predicting Netflix stock prices using multiple machine learning models.

## Models Used:
1. Linear Regression
2. Lasso Regression
3. Random Forest
4. XGBoost

The project includes:
- Model training and evaluation
- Visualizations
