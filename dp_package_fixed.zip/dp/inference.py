
# Inference script to load model and predict
import pickle
import pandas as pd

# Load model
model = pickle.load(open('dp/models/xgboost/xgboost_model.pkl', 'rb'))

# Example input data (replace with actual data for inference)
input_data = pd.DataFrame({
    'Open': [500],
    'High': [510],
    'Low': [495],
    'Volume': [3000000]
})

# Predicting
prediction = model.predict(input_data)
print(f"Predicted Closing Price: {prediction[0]}")
