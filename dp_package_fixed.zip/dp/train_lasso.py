
# Training script for Lasso Regression
import pandas as pd
from sklearn.linear_model import Lasso
from sklearn.model_selection import train_test_split

# Load dataset
df = pd.read_csv('NFLX.csv')

# Feature Selection
X = df[['Open', 'High', 'Low', 'Volume']]
y = df['Close']

# Splitting Data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Lasso Regression
lasso_model = Lasso(alpha=0.1, random_state=42)
lasso_model.fit(X_train, y_train)

# Save the model
import pickle
pickle.dump(lasso_model, open('dp/models/lasso/lasso_model.pkl', 'wb'))
