
# Training script for Linear Regression, Random Forest, XGBoost
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

# Load dataset (replace with the path to your data)
df = pd.read_csv('NFLX.csv')

# Feature Selection
X = df[['Open', 'High', 'Low', 'Volume']]
y = df['Close']

# Splitting Data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Linear Regression
lr_model = LinearRegression()
lr_model.fit(X_train, y_train)

# Random Forest
rf_model = RandomForestRegressor(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)

# XGBoost
xgb_model = XGBRegressor(n_estimators=100, random_state=42)
xgb_model.fit(X_train, y_train)

# Save models
import pickle
pickle.dump(lr_model, open('dp/models/linear_regression/linear_regression_model.pkl', 'wb'))
pickle.dump(rf_model, open('dp/models/random_forest/random_forest_model.pkl', 'wb'))
pickle.dump(xgb_model, open('dp/models/xgboost/xgboost_model.pkl', 'wb'))

